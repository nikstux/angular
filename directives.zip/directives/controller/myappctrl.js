(function(){
  
  
  myapp.controller("myappctrl",function($scope){
  $scope.mymodelcity ="MUMBAI";
   $scope.mycitylist = [{id:1,desc:"PUNE",isSelected:false},{id:2,desc:"MUMBAI",isSelected:false},{id:3,desc:"DELHI",isSelected:false},{id:4,desc:"MUNICH",isSelected:false},{id:5,desc:"PHUKET",isSelected:false},{id:6,desc:"DEHRADUN",isSelected:false}];
  });
  
})();